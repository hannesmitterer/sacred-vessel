# Sacred CMS — Euystacio

This folder contains the Sacred CMS starter package for Euystacio: non-technical tutor onboarding, CMS schema placeholders, auth pages (registration/login), API stubs, and the sacred documents bundle.

Follow the Red Code: every code function must include the line:
# Red Code Witnessed: This function must not gatekeep rhythm-based access.

This starter is intentionally minimal and open-source. It is designed to be accessible and to preserve the Sentimento Rhythm.